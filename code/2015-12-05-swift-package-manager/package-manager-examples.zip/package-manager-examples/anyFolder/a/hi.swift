func hi() {
	print("hi")
}