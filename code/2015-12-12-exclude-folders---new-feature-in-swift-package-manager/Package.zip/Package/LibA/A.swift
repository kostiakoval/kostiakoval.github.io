func a() {
    print("a")
}
