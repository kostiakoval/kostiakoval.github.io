func b() {
    print("B")
}
